// Bitte beantworten Sie die Multiple-Choice-Fragen (maximal 25 Punkte, 1 Punkt pro 'Choice').

public class MCTest {

    // Wenn 'answer' in 'new Choice(...)' für davor stehende 'question' zutrifft, 'valid' bitte auf 'true' ändern.
    // Sonst 'valid' auf 'false' belassen (oder auf 'false' zurückändern).
    // Kommentare sind erlaubt, wirken sich aber nicht auf die Beurteilung aus.
    // Bitte sonst nichts ändern. Zur Kontrolle MCTest ausführen.
    public static void main(String[] args) {
        MCQuestion.checkAndPrint(

                new MCQuestion(
                        "x sei eine Referenz auf einen Knoten (Typ Node) in einer einfach verketteten Liste\n" +
                        "mit mindestens einem existierenden Nachfolger (in der Objektvariablen next).\n" +
                        "Welche der folgenden Anweisungs-Sequenzen entfernen den direkten Nachfolger von x\n" +
                        "aus einer Liste, ändern sonst aber nichts?",

                        new Choice(false, "x.next = x.next.next;"),
                        new Choice(false, "x.next.next.next = x.next.next;"),
                        new Choice(false, "Node d = x.next; d = d.next;"),
                        new Choice(false, "Node n = x.next.next; x.next = n;"),
                        new Choice(false, "x.next.next = x.next.next.next;")
                ),

                new MCQuestion(
                        "Welche der folgenden Aussagen stimmen in Bezug auf Datenabstraktion?",

                        new Choice(false, "Data-Hiding behindert die Datenabstraktion."),
                        new Choice(false, "Datenkapselung ist ein anderer Begriff für Data-Hiding."),
                        new Choice(false, "Datenabstraktion verhindert Änderungen von Objektzuständen."),
                        new Choice(false, "Datenkapselung fügt Variablen und Methoden zu einer Einheit zusammen."),
                        new Choice(false, "Datenkapselung und Data-Hiding sind für Datenabstraktion nötig.")
                ),

                new MCQuestion(
                        "Welche der folgenden Aussagen gelten in Java für die unterschiedlichen\n" +
                        "Arten von Variablen und Parametern?",

                        new Choice(false, "Lokale Referenzvariablen werden automatisch vorinitialisiert."),
                        new Choice(false, "Klassenvariablen werden mit  static  deklariert."),
                        new Choice(false, "Klassenvariablen werden bei der Objekterzeugung angelegt."),
                        new Choice(false, "Objektvariablen werden automatisch vorinitialisiert."),
                        new Choice(false, "Formale Parameter und lokale Variablen können gleich heißen.")
                ),

                new MCQuestion(
                        "t sei eine Variable mit einem einfachen (unbalancierten) binären Suchbaum\n" +
                        "ganzer Zahlen, der durch diese Anweisungen aufgebaut wurde:\n" +
                        "    STree t = new STree(); t.add(4); t.add(9); t.add(7);\n" +
                        "Welche der folgenden Aussagen treffen auf t zu?",

                        new Choice(false, "Der Knoten mit Wert 9 hat zumindest ein Kind."),
                        new Choice(false, "Der Baum hat eine Tiefe von 2."),
                        new Choice(false, "Der Knoten mit Wert 9 ist ein Blattknoten."),
                        new Choice(false, "Der Knoten mit Wert 4 ist die Wurzel."),
                        new Choice(false, "Der Baum hat eine Tiefe von 3.")
                ),

                new MCQuestion(
                        "S und T seien Referenztypen, sodass der Compiler folgenden Programmtext\n" +
                        "fehlerfrei compiliert:  T x = new S();  x.foo();\n" +
                        "Welche der folgenden Aussagen treffen für alle passenden S, T, x und foo() zu?",

                        new Choice(false, "Es gilt:  x.getClass() == T.class"),
                        new Choice(false, "Kommentare zu foo() in T müssen auch auf foo() in S zutreffen."),
                        new Choice(false, "Die Methode foo() muss in S vorkommen, in T aber nicht."),
                        new Choice(false, "S ist Untertyp von T."),
                        new Choice(false, "Die Methode foo() muss in S und T vorkommen.")
                )
        );
    }

    public static final long UID = 238497522434664L;

}
