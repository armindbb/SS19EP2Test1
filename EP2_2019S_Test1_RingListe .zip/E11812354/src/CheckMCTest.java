// Bitte nicht ändern. 'CheckMCTest' wird von anderen Klassen verwendet.
public class CheckMCTest {

    public static final String EXPECT =
            " 1. x sei eine Referenz auf einen Knoten (Typ Node) in einer einfach verketteten Liste\n" +
            "    mit mindestens einem existierenden Nachfolger (in der Objektvariablen next).\n" +
            "    Welche der folgenden Anweisungs-Sequenzen entfernen den direkten Nachfolger von x\n" +
            "    aus einer Liste, ändern sonst aber nichts?\n" +
            "    \n" +
            "    XXXXXXXXX x.next = x.next.next;\n" +
            "    XXXXXXXXX x.next.next.next = x.next.next;\n" +
            "    XXXXXXXXX Node d = x.next; d = d.next;\n" +
            "    XXXXXXXXX Node n = x.next.next; x.next = n;\n" +
            "    XXXXXXXXX x.next.next = x.next.next.next;\n" +
            "\n" +
            " 2. Welche der folgenden Aussagen stimmen in Bezug auf Datenabstraktion?\n" +
            "    \n" +
            "    XXXXXXXXX Data-Hiding behindert die Datenabstraktion.\n" +
            "    XXXXXXXXX Datenkapselung ist ein anderer Begriff für Data-Hiding.\n" +
            "    XXXXXXXXX Datenabstraktion verhindert Änderungen von Objektzuständen.\n" +
            "    XXXXXXXXX Datenkapselung fügt Variablen und Methoden zu einer Einheit zusammen.\n" +
            "    XXXXXXXXX Datenkapselung und Data-Hiding sind für Datenabstraktion nötig.\n" +
            "\n" +
            " 3. Welche der folgenden Aussagen gelten in Java für die unterschiedlichen\n" +
            "    Arten von Variablen und Parametern?\n" +
            "    \n" +
            "    XXXXXXXXX Lokale Referenzvariablen werden automatisch vorinitialisiert.\n" +
            "    XXXXXXXXX Klassenvariablen werden mit  static  deklariert.\n" +
            "    XXXXXXXXX Klassenvariablen werden bei der Objekterzeugung angelegt.\n" +
            "    XXXXXXXXX Objektvariablen werden automatisch vorinitialisiert.\n" +
            "    XXXXXXXXX Formale Parameter und lokale Variablen können gleich heißen.\n" +
            "\n" +
            " 4. t sei eine Variable mit einem einfachen (unbalancierten) binären Suchbaum\n" +
            "    ganzer Zahlen, der durch diese Anweisungen aufgebaut wurde:\n" +
            "        STree t = new STree(); t.add(4); t.add(9); t.add(7);\n" +
            "    Welche der folgenden Aussagen treffen auf t zu?\n" +
            "    \n" +
            "    XXXXXXXXX Der Knoten mit Wert 9 hat zumindest ein Kind.\n" +
            "    XXXXXXXXX Der Baum hat eine Tiefe von 2.\n" +
            "    XXXXXXXXX Der Knoten mit Wert 9 ist ein Blattknoten.\n" +
            "    XXXXXXXXX Der Knoten mit Wert 4 ist die Wurzel.\n" +
            "    XXXXXXXXX Der Baum hat eine Tiefe von 3.\n" +
            "\n" +
            " 5. S und T seien Referenztypen, sodass der Compiler folgenden Programmtext\n" +
            "    fehlerfrei compiliert:  T x = new S();  x.foo();\n" +
            "    Welche der folgenden Aussagen treffen für alle passenden S, T, x und foo() zu?\n" +
            "    \n" +
            "    XXXXXXXXX Es gilt:  x.getClass() == T.class\n" +
            "    XXXXXXXXX Kommentare zu foo() in T müssen auch auf foo() in S zutreffen.\n" +
            "    XXXXXXXXX Die Methode foo() muss in S vorkommen, in T aber nicht.\n" +
            "    XXXXXXXXX S ist Untertyp von T.\n" +
            "    XXXXXXXXX Die Methode foo() muss in S und T vorkommen.\n" +
            "\n";

    public static final long UID = 238497522434664L;

}
