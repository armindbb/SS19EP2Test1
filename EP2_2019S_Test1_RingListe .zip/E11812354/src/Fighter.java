// This class represents a fighting character in a role playing game. Every
// fighter has a name and a number of hitpoints.
//
public class Fighter {

    // # 5 von 5 Punkten für Variablen und Konstruktor
    // TODO: declare variables
    private String name;
    private int hitpoints;

    // A constructor with the 'name' of the fighter and his 'hitpoints'.
    public Fighter(String name, int hitpoints) {
        // TODO: implement this constructor
        this.name = name;
        this.hitpoints = hitpoints;
    }

    // Simulates a fight-to-the-death between 'this' and 'opponent'.
    // The fighter with more 'hitpoints' wins. His hitpoints are reduced
    // by the hitpoints of the losing fighter. The losing fighter is dead
    // after the fight (see method 'isDead').
    // In the case of equal hitpoints, both fighters are dead after the fight.
    // Precondition: opponent != null (needs not be checked).
    public void fights(Fighter opponent) {
        // # 6 von 6 Punkten für fights()
        // TODO: implement this methodfalse
        if (opponent==null) return;

        if(opponent.hitpoints> this.hitpoints) {
            opponent.hitpoints -= this.hitpoints;
            this.hitpoints = 0;
        }

        else if (opponent.hitpoints<this.hitpoints){
            this.hitpoints -= opponent.hitpoints;
            opponent.hitpoints = 0;
        }
        else {
            this.hitpoints = 0;
            opponent.hitpoints =0;
        }


    }

    // Returns 'false' in the case of positive hitpoints, otherwise
    // it returns 'true'.
    public boolean isDead() {
        // # 4 von 4 Punkten für isDead()
        // TODO: implement this method

        if (this.hitpoints > 0){ return false;
        }

        else return true;
    }

    // Returns a representation of this player with his name and his hitpoints in
    // parentheses. If this fighter is dead, hitpoints are 0.
    public String toString() {
        // # 4 von 5 Punkten für toString(); hitpoints kann negtiv sein (Konstruktor)
        // TODO: implement this method
        return "" + this.name + "(" + this.hitpoints +")";
    }

}

